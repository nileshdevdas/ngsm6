import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { PubsubService } from '../pubsub.service';

@Component({
  selector: 'app-loginpage',
  templateUrl: './loginpage.component.html',
  styleUrls: ['./loginpage.component.css']
})
export class LoginpageComponent implements OnInit {
  username: string = '';
  password: string = ''
  constructor(private router: Router, private pubsub: PubsubService, private currentRoute: ActivatedRoute) { }

  handleLogin() {
    console.log(this.username);
    console.log(this.password);
    let path = "";
    this.currentRoute.params.subscribe(param => {
      path = param.origin;
    })
    // store the data in the storage so others can view or share the 
    sessionStorage.setItem("loggedin", "true");
    // sent the events to eveyone who wish monitor that you are logged in successfully 
    this.pubsub.getLoginPublisher().next({ "status": "logged", "tokenid": "299394848488484" });
    if (path === 'login' || path == undefined) {
      path = ''
    }
    this.router.navigate([path])
  }
  ngOnInit() {

  }

}






