import { TestBed, async, inject } from '@angular/core/testing';

import { AuthfilterGuard } from './authfilter.guard';
import { RouterModule } from '@angular/router';
import { routes } from './router';
describe('AuthfilterGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AuthfilterGuard],
      imports: [RouterModule.forRoot(routes)]
    });
  });

  it('should ...', inject([AuthfilterGuard], (guard: AuthfilterGuard) => {
    expect(guard).toBeTruthy();
  }));
});
