import { TestBed } from '@angular/core/testing';

import { PubsubService } from './pubsub.service';
import { HttpClientModule } from '@angular/common/http';

describe('PubsubService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [HttpClientModule]
  }));

  it('should be created', () => {
    const service: PubsubService = TestBed.get(PubsubService);
    expect(service).toBeTruthy();
  });
});
