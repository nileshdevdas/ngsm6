import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-oops404page',
  templateUrl: './oops404page.component.html',
  styleUrls: ['./oops404page.component.css']
})
export class Oops404pageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
