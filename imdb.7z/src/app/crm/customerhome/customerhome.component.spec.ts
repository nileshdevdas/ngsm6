import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerhomeComponent } from './customerhome.component';
import { RouterModule } from '@angular/router';
import { crmroutes } from '../../router';
import { CustomerlistComponent } from '../customerlist/customerlist.component';
import { CustomerinfoComponent } from '../customerinfo/customerinfo.component';
import { Oops404pageComponent } from 'src/app/oops404page/oops404page.component';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { CrmModule } from '../crm.module';
import { CurrencyconvertorPipe } from 'src/app/currencyconvertor.pipe';
import { SelectionhighlighterDirective } from 'src/app/selectionhighlighter.directive';
import { SignuppageComponent } from 'src/app/signuppage/signuppage.component';
import { LoginpageComponent } from 'src/app/loginpage/loginpage.component';
import { EventspageComponent } from 'src/app/eventspage/eventspage.component';
import { TelevisionpageComponent } from 'src/app/televisionpage/televisionpage.component';
import { MoviespageComponent } from 'src/app/moviespage/moviespage.component';
import { HomepageComponent } from 'src/app/homepage/homepage.component';
import { MoviedetailComponent } from 'src/app/moviedetail/moviedetail.component';
import { MovielistComponent } from 'src/app/movielist/movielist.component';
import { MainlayoutComponent } from 'src/app/mainlayout/mainlayout.component';
import { SidebarComponent } from 'src/app/sidebar/sidebar.component';
import { FooterComponent } from 'src/app/footer/footer.component';
import { NavbarComponent } from 'src/app/navbar/navbar.component';
import { AppComponent } from 'src/app/app.component';
describe('CustomerhomeComponent', () => {
  let component: CustomerhomeComponent;
  let fixture: ComponentFixture<CustomerhomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        AppComponent,
        AppComponent,
        NavbarComponent,
        FooterComponent,
        MainlayoutComponent,
        SidebarComponent,
        MovielistComponent,
        MoviedetailComponent,
        HomepageComponent,
        MoviespageComponent,
        TelevisionpageComponent,
        EventspageComponent,
        Oops404pageComponent,
        LoginpageComponent,
        SignuppageComponent,
        SelectionhighlighterDirective,
        CurrencyconvertorPipe
      ],
      imports: [
        BrowserModule,
        HttpClientModule,
        FormsModule,
        CrmModule,
        RouterModule.forRoot(routes)]
    }).compileComponents();
  }))
    .compileComponents();
}));

beforeEach(() => {
  fixture = TestBed.createComponent(CustomerhomeComponent);
  component = fixture.componentInstance;
  fixture.detectChanges();
});

it('should create', () => {
  expect(component).toBeTruthy();
});
});
