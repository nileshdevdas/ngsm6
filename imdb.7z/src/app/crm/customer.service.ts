import { Injectable } from '@angular/core';
import { CrmModule } from './crm.module';

@Injectable({
  providedIn: CrmModule
})
export class CustomerService {
  constructor() {
    console.log("In the constructor....")
  }

  getData() {
    return "xxx";
  }
}
