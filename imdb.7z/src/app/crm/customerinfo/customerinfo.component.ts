import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customerinfo',
  templateUrl: './customerinfo.component.html',
  styleUrls: ['./customerinfo.component.css']
})
export class CustomerinfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
