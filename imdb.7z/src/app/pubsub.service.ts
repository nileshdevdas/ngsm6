import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, from } from 'rxjs';
import * as operators from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PubsubService {
  
  mvlist = [
    {
      'name': 'Harry Potter',
      'summary': "When Harry Potter learns on his eleventh birthday that he is, in fact, a wizard, he is quickly swept up into the spellbinding world of Hogwarts School of Witchcraft and Wizardry alongside new best friends, Ron Weasley and Hermione Granger. He soon discovers, though, that there is a much darker side to the wizarding world than any of them could have imagined.",
      "banner": 'http://t0.gstatic.com/images?q=tbn:ANd9GcT_9nrOnN8sYfZZHJ06EIBSoEO5qjx7uHHEs6VtKNplGVuGhZuC'
    }, {
      'name': 'James Bond',
      'summary': "The James Bond series focuses on a fictional British Secret Service agent created in 1953 by writer Ian Fleming, who featured him in twelve novels and two short-story collections. Since Fleming's death in 1964, eight other authors have written authorised Bond novels or novelizations: Kingsley Amis, Christopher Wood, John Gardner, Raymond Benson, Sebastian Faulks, Jeffery Deaver, William Boyd and Anthony Horowitz. The latest novel is Forever and a Day by Anthony Horowitz, published in May 2018. Additionally Charlie Higson wrote a series on a young James Bond, and Kate Westbrook wrote three novels based on the diaries of a recurring series character, Moneypenny.",
      "banner": 'https://usercontent1.hubstatic.com/13732054_f520.jpg'
    }, {
      'name': 'Sherlock Holmes',
      'summary': "Sherlock is a British crime drama television series based on Sir Arthur Conan Doyle's Sherlock Holmes detective stories. Created by Steven Moffat and Mark Gatiss, it stars Benedict Cumberbatch as Sherlock Holmes and Martin Freeman as Doctor John Watson. 13 episodes have been produced, with four three-part series airing from 2010 to 2017, and a special episode that aired on 1 January 2016. The series is set in the present day, while the one-off special features a Victorian period fantasy resembling the original Holmes stories. Sherlock is produced by the British network BBC, along with Hartswood Films, with Moffat, Gatiss, Sue Vertue and Rebecca Eaton serving as executive producers. The series is supported by the American station WGBH-TV Boston for its Masterpiece anthology series on PBS, where it also airs in the United States.[2][3][4] The series is primarily filmed in Cardiff, Wales, with North Gower Street in London used for exterior shots of Holmes and Watson's 221B Baker Street residence.",
      "banner": 'https://images.justwatch.com/poster/8927990/s592'
    }
  ]

  subject: BehaviorSubject<any> = new BehaviorSubject<any>("Harry Potter")
  loginSubject: BehaviorSubject<any> = new BehaviorSubject<any>("initial");

  constructor(private httpclient: HttpClient) {
  }
  getSubscriber() {
    return this.subject.asObservable();
  }
  getPublisher() {
    return this.subject;
  }



  getLoginSubscriber(): Observable<any> {
    return this.loginSubject.asObservable();
  }

  getLoginPublisher() {
    return this.loginSubject;
  }

  getMovie(movieinput: string): Observable<any> {
    return from(this.mvlist).pipe(operators.filter(movie => movie.name == movieinput));
  }
}




























