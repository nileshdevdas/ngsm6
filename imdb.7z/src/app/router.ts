import { HomepageComponent } from "./homepage/homepage.component";
import { MoviespageComponent } from "./moviespage/moviespage.component";
import { TelevisionpageComponent } from "./televisionpage/televisionpage.component";
import { EventspageComponent } from "./eventspage/eventspage.component";
import { Oops404pageComponent } from "./oops404page/oops404page.component";
import { LoginpageComponent } from "./loginpage/loginpage.component";
import { SignuppageComponent } from "./signuppage/signuppage.component";
import { AuthfilterGuard } from "./authfilter.guard";
import { Routes } from "@angular/router";
import { CustomerhomeComponent } from './crm/customerhome/customerhome.component'
import { CustomerlistComponent } from "./crm/customerlist/customerlist.component";
import { CustomerinfoComponent } from "./crm/customerinfo/customerinfo.component";
export const routes: Routes = [
    { path: '', component: HomepageComponent },
    { path: 'movies', component: MoviespageComponent, canActivate: [AuthfilterGuard] },
    { path: 'television', component: TelevisionpageComponent, canActivate: [AuthfilterGuard] },
    { path: 'events', component: EventspageComponent, canActivate: [AuthfilterGuard] },
    { path: 'login', component: LoginpageComponent },
    { path: 'signup', component: SignuppageComponent },
    { path: '**', component: Oops404pageComponent }
]

export const crmroutes: Routes = [
    {
        path: 'crm',
        component: CustomerhomeComponent,
        children: [
            {
                path: '', component: CustomerinfoComponent
            },
            {
                path: 'info', component: CustomerinfoComponent
            },
            {
                path: 'list', component: CustomerlistComponent
            },
            {
                path: '**', component: Oops404pageComponent
            }
        ]
    }
]


















