import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-moviespage',
  templateUrl: './moviespage.component.html',
  styleUrls: ['./moviespage.component.css']
})
export class MoviespageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
