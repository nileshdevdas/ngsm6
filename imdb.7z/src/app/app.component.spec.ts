import { TestBed, async } from '@angular/core/testing';
import { AppComponent } from './app.component';
import { CurrencyconvertorPipe } from './currencyconvertor.pipe';
import { SelectionhighlighterDirective } from './selectionhighlighter.directive';
import { SignuppageComponent } from './signuppage/signuppage.component';
import { LoginpageComponent } from './loginpage/loginpage.component';
import { Oops404pageComponent } from './oops404page/oops404page.component';
import { EventspageComponent } from './eventspage/eventspage.component';
import { TelevisionpageComponent } from './televisionpage/televisionpage.component';
import { MoviespageComponent } from './moviespage/moviespage.component';
import { HomepageComponent } from './homepage/homepage.component';
import { MoviedetailComponent } from './moviedetail/moviedetail.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { MainlayoutComponent } from './mainlayout/mainlayout.component';
import { MovielistComponent } from './movielist/movielist.component';
import { FooterComponent } from './footer/footer.component';
import { NavbarComponent } from './navbar/navbar.component';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { CrmModule } from './crm/crm.module';
import { RouterModule } from '@angular/router';
import { routes } from './router';
describe('AppComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        AppComponent,
        AppComponent,
        NavbarComponent,
        FooterComponent,
        MainlayoutComponent,
        SidebarComponent,
        MovielistComponent,
        MoviedetailComponent,
        HomepageComponent,
        MoviespageComponent,
        TelevisionpageComponent,
        EventspageComponent,
        Oops404pageComponent,
        LoginpageComponent,
        SignuppageComponent,
        SelectionhighlighterDirective,
        CurrencyconvertorPipe
      ],
      imports: [
        BrowserModule,
        HttpClientModule,
        FormsModule,
        CrmModule,
        RouterModule.forRoot(routes)]
    }).compileComponents();
  }));

  it('should create the app', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app).toBeTruthy();
  });

  it(`should have as title 'imdb'`, () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.debugElement.componentInstance;
    expect(app.title).toEqual('imdb');
  });

  it('should render title in a h1 tag', () => {
    const fixture = TestBed.createComponent(AppComponent);
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('h1').textContent).toContain('Welcome to imdb!');
  });
});
