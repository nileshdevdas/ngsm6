import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: '[appSelectionhighlighter]',
  //inputs: ['oncolor', 'offcolor']
})
export class SelectionhighlighterDirective {
  oncolor: string;
  offcolor: string;
  constructor(private elem: ElementRef) {
    elem.nativeElement.innerHTML = '<div class="jumbotron">Hello </div>'
  }
  @HostListener("mouseover")
  whenmouseover() {
    this.elem.nativeElement.innerHTML = '<button class="btn btn-warning">Hello </button>'
    console.log(this.oncolor);
    console.log(this.offcolor);
  }
  @HostListener("mouseout")
  whenmouseout() {
    console.log("mouse is out")
  }
  @HostListener("mousedown")
  whenmousedown() {
    console.log("mouse is down")
  }
  @HostListener("mouseup")
  whenmouseup() {
    console.log("mouse is up")
  }

}
