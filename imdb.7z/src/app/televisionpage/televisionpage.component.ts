import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-televisionpage',
  templateUrl: './televisionpage.component.html',
  styleUrls: ['./televisionpage.component.css']
})
export class TelevisionpageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
