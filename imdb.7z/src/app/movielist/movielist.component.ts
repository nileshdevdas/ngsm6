import { Component, OnInit } from '@angular/core';
import { MovielistService } from '../movielist.service';
import { PubsubService } from '../pubsub.service';
@Component({
  selector: 'app-movielist',
  templateUrl: './movielist.component.html',
  styleUrls: ['./movielist.component.css']
})
export class MovielistComponent implements OnInit {
  movies;
  loading = false;
  blinker = '';
  randomvalueFromService;
  constructor(private service: MovielistService, private pubsub: PubsubService) { }
  ngOnInit() {
    this.loading = true
    this.service.getMovieList().subscribe(result => {
      this.movies = result
      this.loading = false;
    });
  }
  handleClick(clickEvent) {
    console.log("Sending .... ")
    let eventData = clickEvent.target.innerHTML
    this.pubsub.getPublisher().next(eventData);
  }
}




















