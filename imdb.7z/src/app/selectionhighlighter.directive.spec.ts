import { SelectionhighlighterDirective } from './selectionhighlighter.directive';

describe('SelectionhighlighterDirective', () => {
  it('should create an instance', () => {
    //const directive = new SelectionhighlighterDirective();
    //expect(directive).toBeTruthy();
  });
});
