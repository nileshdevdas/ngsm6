import { Component, OnInit } from '@angular/core';
import { PubsubService } from '../pubsub.service';
import { Router } from '@angular/router';
import { CustomerService } from '../crm/customer.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  websitename = "Vinsys"
  loggedin = false;
  constructor(private pubsub: PubsubService, private router: Router, private cService: CustomerService) { }

  ngOnInit() {
    console.log(this.cService)
    this.pubsub.getLoginSubscriber().subscribe(loginresult => {
      console.log(loginresult)
      if (sessionStorage.getItem("loggedin") != null) {
        this.loggedin = true;
      }
    })
  }

  handleLogout() {
    sessionStorage.clear();
    this.pubsub.getLoginPublisher().next("loggedout");
    this.loggedin = false;
    this.router.navigate(['login'])
  }
}
