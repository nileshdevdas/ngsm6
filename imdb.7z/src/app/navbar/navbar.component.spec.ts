import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NavbarComponent } from './navbar.component';
import { RouterModule } from '@angular/router';
import { routes } from '../router';
import { CurrencyconvertorPipe } from '../currencyconvertor.pipe';
import { SelectionhighlighterDirective } from '../selectionhighlighter.directive';
import { SignuppageComponent } from '../signuppage/signuppage.component';
import { LoginpageComponent } from '../loginpage/loginpage.component';
import { Oops404pageComponent } from '../oops404page/oops404page.component';
import { EventspageComponent } from '../eventspage/eventspage.component';
import { TelevisionpageComponent } from '../televisionpage/televisionpage.component';
import { MoviespageComponent } from '../moviespage/moviespage.component';
import { HomepageComponent } from '../homepage/homepage.component';
import { MoviedetailComponent } from '../moviedetail/moviedetail.component';
import { MovielistComponent } from '../movielist/movielist.component';
import { SidebarComponent } from '../sidebar/sidebar.component';
import { MainlayoutComponent } from '../mainlayout/mainlayout.component';
import { FooterComponent } from '../footer/footer.component';
import { AppComponent } from '../app.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
describe('NavbarComponent', () => {
  let component: NavbarComponent;
  let fixture: ComponentFixture<NavbarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [NavbarComponent, AppComponent,
        NavbarComponent,
        FooterComponent,
        MainlayoutComponent,
        SidebarComponent,
        MovielistComponent,
        MoviedetailComponent,
        HomepageComponent,
        MoviespageComponent,
        TelevisionpageComponent,
        EventspageComponent,
        Oops404pageComponent,
        LoginpageComponent,
        SignuppageComponent,
        SelectionhighlighterDirective,
        CurrencyconvertorPipe],
      imports: [RouterModule.forRoot(routes), FormsModule, HttpClientModule]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NavbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
