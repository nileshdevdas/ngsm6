import { Component, OnInit } from '@angular/core';
import { MovielistService } from '../movielist.service';
import { PubsubService } from '../pubsub.service';
import * as $ from 'jquery';
@Component({
  selector: 'app-moviedetail',
  templateUrl: './moviedetail.component.html',
  styleUrls: ['./moviedetail.component.css']
})
export class MoviedetailComponent implements OnInit {
  eventData;
  showDetail;
  ratings = [1, 2, 3, 4];
  constructor(private movieservice: MovielistService, private pubsub: PubsubService) {
  }

  ngOnInit() {
    this.pubsub.getSubscriber().subscribe((eventMessage) => {
      $("#mdetails").hide();
      $("#mdetails").slideDown(2000);
      this.pubsub.getMovie(eventMessage).subscribe(result => this.showDetail = result);
    });
  }
}
